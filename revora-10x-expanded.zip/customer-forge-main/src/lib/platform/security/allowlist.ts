export function allowlisted<T extends string>(value: T, values: readonly T[]): boolean { return values.includes(value); }
export function assertAllowlisted<T extends string>(value:T, values:readonly T[]):T { if (!allowlisted(value,values)) throw new Error('Value is not allowlisted'); return value; }
