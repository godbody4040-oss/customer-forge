export const PLAYBOOKS=['failed_launch','low_lead_volume','low_booking_rate','billing_risk','domain_issue','high_support_volume','churn_risk'] as const; export type Playbook=typeof PLAYBOOKS[number];
