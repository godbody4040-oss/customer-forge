export type SitemapUrl={loc:string;lastmod?:string;changefreq?:string;priority?:number};
export const sitemapEntry=(loc:string,lastmod?:string):SitemapUrl=>({loc,lastmod});
