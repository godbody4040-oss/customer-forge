export type DeletionRequest={id:string;organizationId:string;requestedAt:string;executeAfter:string;status:'requested'|'approved'|'executed'|'cancelled'};
export const deletable=(r:DeletionRequest,now=Date.now()):boolean=>r.status==='approved'&&new Date(r.executeAfter).getTime()<=now;
