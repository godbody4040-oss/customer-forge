export interface Cache<K,V>{get(key:K):Promise<V|undefined>;set(key:K,value:V,ttlMs:number):Promise<void>;delete(key:K):Promise<void>;}
