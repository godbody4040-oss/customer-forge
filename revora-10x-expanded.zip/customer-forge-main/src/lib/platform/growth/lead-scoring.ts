export type LeadSignals={formComplete:number;responseMinutes:number;pagesViewed:number;pricingViewed:boolean;serviceMatch:number;sourceQuality:number};
export function scoreLead(s:LeadSignals):number{const speed=Math.max(0,100-Math.min(100,s.responseMinutes/5));const raw=s.formComplete*.2+speed*.15+Math.min(100,s.pagesViewed*12)*.1+(s.pricingViewed?100:0)*.1+s.serviceMatch*.25+s.sourceQuality*.2;return Math.round(Math.max(0,Math.min(100,raw)));}
export const leadTier=(score:number):'hot'|'warm'|'cold'=>score>=75?'hot':score>=45?'warm':'cold';
