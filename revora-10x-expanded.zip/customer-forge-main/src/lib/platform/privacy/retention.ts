export type RetentionPolicy={resource:string;days:number};
export const expiredByPolicy=(createdAt:string,policy:RetentionPolicy,now=Date.now()):boolean=>now-new Date(createdAt).getTime()>policy.days*86_400_000;
