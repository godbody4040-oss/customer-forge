export type SessionAttribution={sessionId:string;source?:string;medium?:string;campaign?:string;landingPath?:string;startedAt:string};
