import { describe, expect, it } from "vitest";
import { placeDisplay } from "./presentation";

describe("placeDisplay", () => {
  it("omits broad placeholder service areas", () => {
    expect(placeDisplay("Any")).toBeNull();
    expect(placeDisplay("Anywhere")).toBeNull();
    expect(placeDisplay("TBD")).toBeNull();
    expect(placeDisplay("All areas")).toBeNull();
  });

  it("keeps real places readable", () => {
    expect(placeDisplay("raleigh, nc")).toBe("Raleigh, NC");
  });
});
