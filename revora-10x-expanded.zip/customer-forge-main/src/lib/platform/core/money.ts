export type Money = { amount: number; currency: string };
export const money = (amount: number, currency='USD'): Money => ({ amount: Math.round(amount * 100) / 100, currency: currency.toUpperCase() });
export const addMoney = (a: Money, b: Money): Money => { if (a.currency !== b.currency) throw new Error('Currency mismatch'); return money(a.amount+b.amount,a.currency); };
