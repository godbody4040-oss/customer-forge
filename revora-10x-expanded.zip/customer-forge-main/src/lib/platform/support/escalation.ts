import { SLA, type SlaTarget } from '../operations/sla'; export const slaFor=(priority:SlaTarget['priority']):SlaTarget=>SLA[priority];
