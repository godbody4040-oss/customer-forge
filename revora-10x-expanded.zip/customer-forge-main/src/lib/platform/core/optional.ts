export const coalesce = <T>(value: T | null | undefined, fallback: T): T => value ?? fallback;
export const mapOptional = <T,U>(value: T | null | undefined, fn:(v:T)=>U): U | undefined => value == null ? undefined : fn(value);
