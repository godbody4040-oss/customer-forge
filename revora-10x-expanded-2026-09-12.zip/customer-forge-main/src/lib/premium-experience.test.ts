import { describe, expect, it } from "vitest";
import { premiumMatch } from "@/lib/premium-experience";

const services = [
  {
    id: "1",
    name: "Interior Deep Clean",
    description: "Steam and extraction for seats, carpets and stains.",
    category: "interior",
    price: 180,
    starting_price: null,
    duration_minutes: 120,
    image_url: null,
    bookable: true,
    featured: true,
    sort_order: 0,
  },
  {
    id: "2",
    name: "Ceramic Coating",
    description: "Long-term paint protection and hydrophobic gloss.",
    category: "exterior",
    price: 900,
    starting_price: 900,
    duration_minutes: 240,
    image_url: null,
    bookable: true,
    featured: false,
    sort_order: 1,
  },
];

describe("premiumMatch", () => {
  it("matches the service using customer language", () => {
    const result = premiumMatch("I need stains removed from my seats", services);
    expect(result?.service.name).toBe("Interior Deep Clean");
  });

  it("prioritizes an exact service-name token", () => {
    const result = premiumMatch("ceramic coating please", services);
    expect(result?.service.name).toBe("Ceramic Coating");
  });

  it("returns null when nothing matches", () => {
    expect(premiumMatch("I need a tow truck", services)).toBeNull();
  });

  it("does not produce a match for empty input", () => {
    expect(premiumMatch("   ", services)).toBeNull();
  });
});
