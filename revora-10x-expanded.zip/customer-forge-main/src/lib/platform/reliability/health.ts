export type HealthCheck={name:string;ok:boolean;latencyMs:number;detail?:string};
export type HealthReport={status:'ok'|'degraded'|'down';checks:HealthCheck[];at:string};
export const summarizeHealth=(checks:HealthCheck[],at=new Date().toISOString()):HealthReport=>({status:checks.every(c=>c.ok)?'ok':checks.some(c=>c.ok)?'degraded':'down',checks,at});
