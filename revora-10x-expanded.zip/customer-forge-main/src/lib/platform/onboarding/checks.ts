export type Check={id:string;label:string;passed:boolean;blocking:boolean}; export const blockingFailures=(checks:Check[]):Check[]=>checks.filter(c=>c.blocking&&!c.passed);
