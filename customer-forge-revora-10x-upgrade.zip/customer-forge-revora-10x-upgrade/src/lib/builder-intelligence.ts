export type SmartGoal = "calls" | "quotes" | "bookings" | "sales" | "leads";

export type SmartBriefInput = {
  businessName?: string | null;
  industry?: string | null;
  description?: string | null;
  city?: string | null;
  state?: string | null;
  serviceArea?: string | null;
  services?: number;
  goals?: string[];
  hasPhone?: boolean;
  hasEmail?: boolean;
  hasHeroImage?: boolean;
  hasProof?: boolean;
};

export type SmartBrief = {
  category: string;
  location: string | null;
  primaryGoal: SmartGoal;
  primaryCta: string;
  pages: string[];
  sections: string[];
  questions: string[];
  readiness: number;
  summary: string;
};

const compact = (value?: string | null) => (value ?? "").trim().replace(/\s+/g, " ");

const contains = (haystack: string, words: string[]) => words.some((word) => haystack.includes(word));

function classify(value: string) {
  const text = value.toLowerCase();
  if (contains(text, ["plumb", "hvac", "roof", "electric", "landscap", "clean", "detail", "contract", "repair", "paint", "pest"])) return "local service";
  if (contains(text, ["salon", "spa", "barber", "fitness", "gym", "massage", "tattoo", "clinic", "dental", "therapy"])) return "appointment business";
  if (contains(text, ["shop", "store", "boutique", "product", "ecommerce", "restaurant", "bakery", "food"])) return "selling business";
  if (contains(text, ["agency", "consult", "coach", "legal", "account", "marketing", "design", "photo"])) return "professional service";
  return "small business";
}

function goalOf(input: SmartBriefInput, category: string): SmartGoal {
  const words = (input.goals ?? []).join(" ").toLowerCase();
  if (contains(words, ["book", "appointment", "schedule"])) return "bookings";
  if (contains(words, ["sale", "shop", "store", "buy"])) return "sales";
  if (contains(words, ["quote", "estimate"])) return "quotes";
  if (contains(words, ["lead", "email", "grow"])) return "leads";
  if (category === "appointment business") return "bookings";
  if (category === "selling business") return "sales";
  if (category === "local service") return "quotes";
  return "calls";
}

const CTA: Record<SmartGoal, string> = {
  calls: "Call now",
  quotes: "Get a free quote",
  bookings: "Book an appointment",
  sales: "Shop now",
  leads: "Get started",
};

export function createSmartBrief(input: SmartBriefInput): SmartBrief {
  const businessName = compact(input.businessName) || "Your business";
  const description = compact(input.description);
  const category = classify(`${compact(input.industry)} ${description}`);
  const primaryGoal = goalOf(input, category);
  const location = [compact(input.city), compact(input.state)].filter(Boolean).join(", ") || compact(input.serviceArea) || null;
  const pages = ["Home", "Services"];
  if (primaryGoal === "bookings") pages.push("Book");
  if (primaryGoal === "sales") pages.push("Shop");
  if (location || category === "local service") pages.push("Service area");
  pages.push("About", "Contact");
  const sections = ["Clear headline", "Primary action", "Services", "Why choose us", "How it works"];
  if (input.hasProof) sections.push("Customer proof");
  if (primaryGoal === "quotes") sections.push("Quote request");
  if (primaryGoal === "bookings") sections.push("Booking");
  const questions: string[] = [];
  if (!description) questions.push("What should visitors understand about your business in one sentence?");
  if (!input.services) questions.push("Which services should be featured first?");
  if (!input.hasPhone && !input.hasEmail) questions.push("How should a ready-to-buy visitor contact you?");
  if (!location && category === "local service") questions.push("What cities or areas do you serve?");
  if (!input.hasProof) questions.push("What real proof can we show: years, credentials, reviews, or project photos?");
  if (!input.hasHeroImage) questions.push("Do you have a real photo or logo for the opening section?");
  const answered = 6 - questions.length;
  const readiness = Math.max(20, Math.min(100, Math.round((answered / 6) * 100)));
  const place = location ? ` for people in ${location}` : "";
  return {
    category,
    location,
    primaryGoal,
    primaryCta: CTA[primaryGoal],
    pages,
    sections,
    questions,
    readiness,
    summary: `${businessName} will start with a ${category} website focused on ${primaryGoal}${place}.`,
  };
}
