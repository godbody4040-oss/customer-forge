export type Touch={channel:string;campaign?:string;at:string};
export function firstTouch(touches:Touch[]):Touch|undefined{return [...touches].sort((a,b)=>a.at.localeCompare(b.at))[0];}
export function lastTouch(touches:Touch[]):Touch|undefined{return [...touches].sort((a,b)=>b.at.localeCompare(a.at))[0];}
