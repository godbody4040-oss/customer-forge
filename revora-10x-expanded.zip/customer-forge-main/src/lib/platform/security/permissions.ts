export const PERMISSIONS = ['workspace.read','workspace.write','billing.read','billing.write','leads.read','leads.write','sites.publish','domains.manage','analytics.read','admin.support'] as const;
export type Permission = typeof PERMISSIONS[number];
export type PermissionSet = ReadonlySet<Permission>;
export const can = (set: PermissionSet, permission: Permission): boolean => set.has(permission);
