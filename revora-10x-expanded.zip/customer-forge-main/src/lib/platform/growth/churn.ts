export const monthlyChurnRate=(cancelled:number,starting:number):number=>starting<=0?0:Math.round(cancelled/starting*10_000)/100;
export const retentionRate=(cancelled:number,starting:number):number=>Math.max(0,100-monthlyChurnRate(cancelled,starting));
