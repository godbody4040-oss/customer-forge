export const conversionRate=(conversions:number,visitors:number):number=>visitors<=0?0:Math.round((conversions/visitors)*10_000)/100;
export const uplift=(before:number,after:number):number=>before===0?0:Math.round(((after-before)/before)*10_000)/100;
