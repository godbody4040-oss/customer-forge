import { describe, expect, it } from "vitest";
import { targetOf } from "@/lib/site-agent.atomic";
import { readComponentVisual, readSectionVisual, writeComponentVisual, writeSectionVisual } from "@/lib/site-style";

describe("site visual action contract", () => {
  it("journals section visual actions", () => {
    expect(targetOf({
      type: "set_section_visual",
      sectionId: "11111111-1111-4111-8111-111111111111",
      patch: { layout: "stacked", density: "balanced" },
    })).toEqual({ kind: "update", table: "website_sections", id: "11111111-1111-4111-8111-111111111111" });
  });

  it("journals component visual actions", () => {
    expect(targetOf({
      type: "set_component_visual",
      componentId: "22222222-2222-4222-8222-222222222222",
      patch: { radius: "large", shadow: "soft" },
    })).toEqual({ kind: "update", table: "website_components", id: "22222222-2222-4222-8222-222222222222" });
  });

  it("rejects an unsupported variant for a known section kind", async () => {
    const { readActions } = await import("@/lib/site-agent");
    const actions = readActions(
      [{ type: "set_section_variant", sectionId: "11111111-1111-4111-8111-111111111111", variant: "not-real" }],
      {
        pageIds: new Set(),
        sectionIds: new Set(["11111111-1111-4111-8111-111111111111"]),
        componentIds: new Set(),
        sectionKinds: new Map([["11111111-1111-4111-8111-111111111111", "hero"]]),
      },
    );
    expect(actions).toEqual([]);
  });

  it("persists only allowlisted section visual values", () => {
    const settings = writeSectionVisual({ effect: "none" }, { layout: "stacked", density: "airy", max_width: "wide" });
    expect(readSectionVisual(settings)).toEqual({ layout: "stacked", density: "airy", max_width: "wide" });
    expect(JSON.stringify(settings)).not.toContain("<script>");
  });

  it("persists safe component visual values", () => {
    const settings = writeComponentVisual({}, { radius: "large", shadow: "medium", object_fit: "cover", alt: "A service photo" });
    expect(readComponentVisual(settings)).toEqual({ radius: "large", shadow: "medium", object_fit: "cover", alt: "A service photo" });
  });
});
