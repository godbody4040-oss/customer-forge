import { recognizedRevenue, type RevenueEvent } from '../growth/revenue'; export const netRevenue=(events:RevenueEvent[]):number=>recognizedRevenue(events);
