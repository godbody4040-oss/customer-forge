export type IncidentSeverity='sev1'|'sev2'|'sev3'|'sev4'; export type Incident={id:string;severity:IncidentSeverity;title:string;startedAt:string;resolvedAt?:string};
export const isOpen=(i:Incident):boolean=>!i.resolvedAt;
