const SECRET_KEYS = new Set(['password','token','access_token','refresh_token','secret','api_key','apikey','authorization','cookie','stripe_secret_key','webhook_secret']);
export function redactObject(input: Record<string, unknown>): Record<string, unknown> { return Object.fromEntries(Object.entries(input).map(([k,v])=>[k,SECRET_KEYS.has(k.toLowerCase())?'[REDACTED]':v])); }
export function redactEmail(email: string): string { const [name,domain]=email.split('@'); return !domain ? '[REDACTED]' : `${(name?.[0] ?? '*')}***@${domain}`; }
