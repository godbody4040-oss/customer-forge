export type EntityId = string & { readonly __brand: 'EntityId' };
export const asEntityId = (value: string): EntityId => value.trim() as EntityId;
export const isEntityId = (value: string): boolean => /^[A-Za-z0-9_-]{8,128}$/.test(value);
