export type JsonLd=Record<string,unknown>;
export const localBusinessSchema=(name:string,url:string,telephone?:string):JsonLd=>({'@context':'https://schema.org','@type':'LocalBusiness',name,url,...(telephone?{telephone}:{})});
