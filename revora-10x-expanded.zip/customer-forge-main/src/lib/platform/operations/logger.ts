import { redactObject } from '../security/redaction';
export type LogLevel='debug'|'info'|'warn'|'error'; export type LogRecord={level:LogLevel;message:string;context:Record<string,unknown>;at:string};
export const logRecord=(level:LogLevel,message:string,context:Record<string,unknown>={}):LogRecord=>({level,message,context:redactObject(context),at:new Date().toISOString()});
