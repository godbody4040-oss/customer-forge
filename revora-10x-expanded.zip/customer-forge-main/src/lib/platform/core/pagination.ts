export type Page<T> = { items: T[]; page: number; pageSize: number; total?: number; hasMore: boolean };
export function normalizePage(page = 1, pageSize = 25): { page: number; pageSize: number; offset: number } {
  const p = Math.max(1, Math.floor(page)); const s = Math.min(100, Math.max(1, Math.floor(pageSize))); return { page:p, pageSize:s, offset:(p-1)*s };
}
