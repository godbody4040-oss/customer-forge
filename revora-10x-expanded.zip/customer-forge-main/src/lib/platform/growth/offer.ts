export type Offer={name:string;price:number;billing:'one_time'|'monthly'|'annual';active:boolean};
export const activeOffers=(offers:Offer[]):Offer[]=>offers.filter(o=>o.active);
