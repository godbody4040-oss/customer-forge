import type { PublicSite } from "@/lib/public-site.functions";

type Service = NonNullable<PublicSite>["services"][number];

export type PremiumMatch = {
  service: Service;
  score: number;
};

const STOP_WORDS = new Set([
  "a", "an", "and", "for", "i", "me", "my", "need", "the", "to", "want", "with",
  "get", "have", "looking", "please", "can", "you", "do", "is", "on", "of",
]);

const tokens = (value: string) =>
  value
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, " ")
    .split(/\s+/)
    .filter((token) => token.length > 2 && !STOP_WORDS.has(token));

/**
 * Deterministic service matching. This is intentionally not presented as an
 * LLM: it is instant, private and grounded only in the services the business
 * has actually published.
 */
export function premiumMatch(query: string, services: Service[]): PremiumMatch | null {
  const wanted = tokens(query);
  if (!wanted.length || !services.length) return null;

  let best: PremiumMatch | null = null;
  for (const service of services) {
    const haystack = tokens(
      [service.name, service.description, service.category].filter(Boolean).join(" "),
    );
    const score = wanted.reduce((total, token) => {
      if (haystack.includes(token)) return total + (service.name.toLowerCase().includes(token) ? 4 : 2);
      return total;
    }, 0);

    if (score > 0 && (!best || score > best.score)) best = { service, score };
  }
  return best;
}
