export type RateLimitResult={allowed:boolean;remaining:number;resetAt:number};
export function fixedWindow(count:number,limit:number,windowMs:number,startedAt:number,now=Date.now()):RateLimitResult{const expired=now-startedAt>=windowMs;const used=expired?0:count;return {allowed:used<limit,remaining:Math.max(0,limit-used-1),resetAt:expired?now+windowMs:startedAt+windowMs};}
