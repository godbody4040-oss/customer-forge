export type Metric={name:string;value:number;unit?:string;at:string;tags?:Record<string,string>};
export const metric=(name:string,value:number,tags?:Record<string,string>):Metric=>({name,value,tags,at:new Date().toISOString()});
