export const marketingRoi=(incrementalRevenue:number,marketingCost:number):number=>marketingCost<=0?0:Math.round(((incrementalRevenue-marketingCost)/marketingCost)*10_000)/100;
