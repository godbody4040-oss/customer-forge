export type ExportBundle={organizationId:string;createdAt:string;resources:Record<string,unknown[]>};
export const exportManifest=(organizationId:string,resources:Record<string,unknown[]>):ExportBundle=>({organizationId,createdAt:new Date().toISOString(),resources});
