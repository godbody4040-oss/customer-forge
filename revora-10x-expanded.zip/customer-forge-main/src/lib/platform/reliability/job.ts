export type JobStatus='queued'|'running'|'succeeded'|'failed'|'dead-letter';
export type Job<T>={id:string;type:string;payload:T;attempts:number;status:JobStatus;runAfter:string};
export const nextJob=(jobs:Job<unknown>[],now=new Date()):Job<unknown>|undefined=>jobs.find(j=>j.status==='queued'&&new Date(j.runAfter)<=now);
