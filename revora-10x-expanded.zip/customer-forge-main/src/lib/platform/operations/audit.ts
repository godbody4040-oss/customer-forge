export type AuditEvent={id:string;action:string;actorId:string;organizationId:string;at:string;metadata:Record<string,unknown>};
export const auditKey=(event:Pick<AuditEvent,'organizationId'|'action'|'at'>):string=>`${event.organizationId}:${event.action}:${event.at}`;
