export function safeJson<T>(value: string, fallback: T): T { try { return JSON.parse(value) as T; } catch { return fallback; } }
export const stableJson = (value: unknown): string => JSON.stringify(value, Object.keys((value ?? {}) as object).sort());
