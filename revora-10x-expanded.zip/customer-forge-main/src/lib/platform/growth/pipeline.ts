export const PIPELINE_STAGES=['new','contacted','qualified','quoted','booked','won','lost'] as const; export type PipelineStage=typeof PIPELINE_STAGES[number];
export const isTerminal=(stage:PipelineStage):boolean=>stage==='won'||stage==='lost';
