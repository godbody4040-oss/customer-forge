export type NotificationChannel='email'|'in_app'|'webhook'; export type Notification={channel:NotificationChannel;template:string;recipient:string;data:Record<string,unknown>};
export const notification=(channel:NotificationChannel,template:string,recipient:string,data:Record<string,unknown>):Notification=>({channel,template,recipient,data});
