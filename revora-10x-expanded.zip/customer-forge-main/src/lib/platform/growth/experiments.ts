export type ExperimentVariant={id:string;visitors:number;conversions:number};
export const rate=(v:ExperimentVariant):number=>v.visitors?v.conversions/v.visitors:0;
export const winner=(variants:ExperimentVariant[]):ExperimentVariant|undefined=>[...variants].sort((a,b)=>rate(b)-rate(a))[0];
