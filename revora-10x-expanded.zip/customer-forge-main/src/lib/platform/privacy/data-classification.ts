export type DataClass='public'|'internal'|'confidential'|'restricted'; export const CLASS_ORDER:Record<DataClass,number>={public:1,internal:2,confidential:3,restricted:4};
export const moreSensitive=(a:DataClass,b:DataClass):DataClass=>CLASS_ORDER[a]>=CLASS_ORDER[b]?a:b;
