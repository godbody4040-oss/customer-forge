export type SubscriptionStatus='trialing'|'active'|'past_due'|'paused'|'canceled'; export type Subscription={id:string;organizationId:string;plan:string;status:SubscriptionStatus;currentPeriodEnd:string};
export const billable=(s:Subscription):boolean=>s.status==='active'||s.status==='trialing'||s.status==='past_due';
