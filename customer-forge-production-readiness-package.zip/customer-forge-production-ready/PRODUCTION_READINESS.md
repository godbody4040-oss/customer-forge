# Production readiness gate

Do not publish a change merely because it synced to Lovable. A release is eligible only after the CI workflow passes and a human has verified the published preview.

## Required checks

- `bun install --frozen-lockfile`
- `bun run typecheck`
- `bun run lint`
- `bun run test`
- `bun run build`
- Desktop and mobile smoke tests for `/`, `/pricing`, `/app`, and a public tenant page
- Supabase migration test on an empty disposable database
- RLS tenant-isolation tests
- Stripe test-mode checkout and signed-webhook tests
- Secrets scan and environment-variable review

## Release process

1. Open a pull request.
2. Require the Verify workflow to pass.
3. Test the Lovable preview, including a mobile viewport.
4. Merge to `main` only after review.
5. Publish from Lovable and smoke-test the live URL.
6. Keep the previous deployment/commit available for rollback.
