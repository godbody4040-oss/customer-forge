export type UTM={source?:string;medium?:string;campaign?:string;term?:string;content?:string};
export const parseUtm=(params:URLSearchParams):UTM=>({source:params.get('utm_source')??undefined,medium:params.get('utm_medium')??undefined,campaign:params.get('utm_campaign')??undefined,term:params.get('utm_term')??undefined,content:params.get('utm_content')??undefined});
