export function sameOrigin(requestOrigin: string | null, expectedOrigin: string): boolean { return Boolean(requestOrigin) && requestOrigin === expectedOrigin; }
export function requireSameOrigin(requestOrigin: string | null, expectedOrigin: string): void { if (!sameOrigin(requestOrigin, expectedOrigin)) throw new Error('CSRF origin check failed'); }
