export type CustomerSignals={loginDays30:number;leads30:number;bookings30:number;supportTickets30:number;daysSinceLaunch:number};
export const customerHealth=(s:CustomerSignals):number=>Math.round(Math.max(0,Math.min(100,40+Math.min(20,s.loginDays30)+Math.min(25,s.bookings30*5)+Math.min(15,s.leads30*2)-Math.min(20,s.supportTickets30*4))));
