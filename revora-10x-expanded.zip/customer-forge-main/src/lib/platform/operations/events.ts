export type DomainEvent<T=unknown>={type:string;payload:T;at:string;id:string};
export const event=<T>(type:string,payload:T):DomainEvent<T>=>({type,payload,at:new Date().toISOString(),id:crypto.randomUUID()});
