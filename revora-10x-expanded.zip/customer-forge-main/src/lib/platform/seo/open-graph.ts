export type OpenGraph={title:string;description:string;url:string;image?:string;type?:'website'|'article'};
