# What's in this zip

Each file below replaces the file at the same path in your repo
(customer-forge-main). Copy them over, then run `npm run typecheck`
and `npx vitest run` before pushing — these were syntax-checked here
but not run against your real dependency tree (no network access on
my end to install them).

## 1. Builder intelligence — self-critique that actually verifies itself
`src/lib/agent/orchestrator.server.ts`
`src/lib/site-agent.functions.ts`
`src/components/app/SiteChatbot.tsx`

- The agent's auto-fix step now **re-grades its own work** after improving a
  plan, instead of just claiming "raised it itself."
- Complex requests get up to 2 graded improvement passes instead of 1.
- Simple requests now get graded too (previously skipped entirely).
- The chat UI surfaces the agent's own top suggested next move, computed
  from its critique of the last plan, as a tappable chip.

## 2. Live bug fix — "Any's go-to team" / "Serving Any"
`src/lib/builder/presentation.ts`
`src/lib/website-content.ts`

Root cause: a business that answered "Any" for its service area got that
literal text used as a place name ("Any's go-to team for auto detailing",
"Serving Any"). `placeDisplay()` now recognizes non-specific answers (any,
n/a, anywhere, tbd, etc.) and treats them as no answer, so the site falls
back to a clean headline instead.

## 3. Tests
`src/lib/builder/presentation.test.ts` — extended with the non-specific-area
cases.
`src/lib/website-content.test.ts` — new file; regression test built directly
from the live bug, plus basic `splitAreas` coverage (no test file existed
for `website-content.ts` before this).

## 4. Tightened the AI-tab intro copy
`src/components/app/SiteChatbot.tsx`

The AI tab opened with a title, a 3-step list, then three more paragraphs
repeating the same information (what Revora can change, listed twice in
slightly different words). Now it's: a short 3-step list, always visible,
plus a "See everything it can build" toggle that expands the full detail
(visuals, multimodal input, lead-gen guidance) only when someone wants it —
so a first-time owner sees a few lines instead of a wall of text.

## Still open (not in this zip)
The "Couldn't apply those changes" generic error banner — the real
per-action failure reason is currently swallowed before it reaches the UI.
Worth fixing next if you want per-item error messages like Lovable/Claude
Code show.
