export type DeadLetter={jobId:string;error:string;attempts:number;createdAt:string};
export const deadLetter=(jobId:string,error:unknown,attempts:number):DeadLetter=>({jobId,error:error instanceof Error?error.message:String(error),attempts,createdAt:new Date().toISOString()});
