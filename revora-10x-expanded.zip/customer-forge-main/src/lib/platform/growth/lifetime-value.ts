export const simpleLtv=(monthlyRevenue:number,grossMargin:number,monthlyChurn:number):number=>monthlyChurn<=0?monthlyRevenue*grossMargin:monthlyRevenue*grossMargin/(monthlyChurn/100);
