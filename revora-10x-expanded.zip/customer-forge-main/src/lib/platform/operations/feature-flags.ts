export type Flag={key:string;enabled:boolean;rollout:number};
export function enabled(flag:Flag,subject=''):boolean{if(!flag.enabled||flag.rollout<=0)return false;if(flag.rollout>=100)return true;let h=0;for(const c of `${flag.key}:${subject}`)h=(h*31+c.charCodeAt(0))>>>0;return h%100<flag.rollout;}
