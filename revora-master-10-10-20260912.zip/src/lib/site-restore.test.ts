import { describe, expect, it } from "vitest";
import { buildFullSnapshot, snapshotsMatch } from "@/lib/site-restore";

describe("full website snapshots", () => {
  it("keeps section/component settings and global design state", () => {
    const snapshot = buildFullSnapshot(
      [
        {
          id: "11111111-1111-4111-8111-111111111111",
          slug: "home",
          title: "Home",
          kind: "home",
          seo_title: "Home",
          seo_description: "A real description",
          seo_canonical: "https://example.com/",
          og_title: "Home",
          og_description: "Share",
          og_image_url: "https://example.com/og.jpg",
          noindex: false,
          sort_order: 0,
          is_visible: true,
        },
      ],
      [
        {
          id: "22222222-2222-4222-8222-222222222222",
          page_id: "11111111-1111-4111-8111-111111111111",
          kind: "hero",
          variant: "stacked",
          heading: "Hello",
          subheading: null,
          body: null,
          settings: { visual: { layout: "stacked" }, effect: "none" },
          sort_order: 0,
          is_visible: true,
        },
      ],
      [
        {
          id: "33333333-3333-4333-8333-333333333333",
          section_id: "22222222-2222-4222-8222-222222222222",
          kind: "image",
          label: "Hero photo",
          body: null,
          link_label: null,
          link_url: null,
          media_url: "https://example.com/photo.jpg",
          settings: { visual: { alt: "A real photo", radius: "large" } },
          sort_order: 0,
          is_visible: true,
        },
      ],
      "2026-09-12T00:00:00.000Z",
      {
        siteSettings: { template: "default", generation: { backdrop: "clean" }, seo: { title: "Home" } },
        theme: { primary_color: "#111111", font_preference: "Inter" },
      },
    );

    expect(snapshot.pages[0]?.sections[0]?.settings).toEqual({
      visual: { layout: "stacked" },
      effect: "none",
    });
    expect(snapshot.pages[0]?.sections[0]?.components[0]?.settings).toEqual({
      visual: { alt: "A real photo", radius: "large" },
    });
    expect(snapshot.siteSettings?.generation).toEqual({ backdrop: "clean" });
    expect(snapshot.theme?.font_preference).toBe("Inter");
    expect(snapshotsMatch(snapshot, { ...snapshot, takenAt: "later" })).toBe(true);
  });
});
