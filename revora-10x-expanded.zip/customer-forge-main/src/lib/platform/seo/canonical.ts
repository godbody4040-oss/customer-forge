export const canonicalUrl=(origin:string,path:string):string=>`${origin.replace(/\/$/,'')}/${path.replace(/^\//,'')}`;
