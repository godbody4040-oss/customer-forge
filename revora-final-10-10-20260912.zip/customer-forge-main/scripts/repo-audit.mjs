#!/usr/bin/env node
import { readFileSync, readdirSync, statSync } from 'node:fs';
import { join, relative } from 'node:path';

const ROOT = process.cwd();
const SRC = join(ROOT, 'src');
const SUPABASE = join(ROOT, 'supabase');
const failures = [];
const warnings = [];

function walk(dir) {
  const out = [];
  if (!statSync(dir, { throwIfNoEntry: false })) return out;
  for (const name of readdirSync(dir)) {
    if (['node_modules', '.git', 'dist', 'build', '.next'].includes(name)) continue;
    const p = join(dir, name);
    const s = statSync(p);
    if (s.isDirectory()) out.push(...walk(p));
    else out.push(p);
  }
  return out;
}
function text(p) { try { return readFileSync(p, 'utf8'); } catch { return ''; } }
function files(root, re = /\.(ts|tsx|js|jsx|mjs|sql|json)$/) { return walk(root).filter(p => re.test(p)); }
function lineOf(src, index) { return src.slice(0, index).split('\n').length; }
function hit(path, pattern, label, hard = false) {
  const src = text(path); const m = src.match(pattern);
  if (!m) return;
  const msg = `${relative(ROOT, path)}:${lineOf(src, m.index ?? 0)} ${label}`;
  (hard ? failures : warnings).push(msg);
}

// 1. Environment/secret hygiene.
for (const p of walk(ROOT)) {
  const n = p.split('/').pop() ?? '';
  if (/^\.env(?:\.|$)/.test(n) && !/\.example$/.test(n)) failures.push(`${relative(ROOT,p)} contains a deploy-time environment file`);
}
for (const p of files(SRC)) {
  if (!/\.(test|spec)\.(ts|tsx|js|jsx)$/.test(p)) hit(p, /(sk_live_|sk_test_|SUPABASE_SERVICE_ROLE_KEY\s*[:=]\s*['"]|BEGIN (?:RSA|OPENSSH|EC) PRIVATE KEY)/, 'possible embedded secret', true);
}

// 2. Agent contract parity: every action literal in the AgentAction union must be handled by the executor.
const agent = text(join(SRC, 'lib/site-agent.ts'));
const executor = text(join(SRC, 'lib/site-agent.functions.ts'));
const union = agent.match(/export\s+type\s+AgentAction\s*=([\s\S]*?)(?:\n\nexport\s+type|\n\/\*|$)/)?.[1] ?? '';
const actions = [...union.matchAll(/type:\s*['"]([^'"]+)['"]/g)].map(m => m[1]);
const missing = [...new Set(actions)].filter(a => !executor.includes(`case "${a}"`) && !executor.includes(`case '${a}'`));
if (missing.length) failures.push(`Agent executor missing actions: ${missing.join(', ')}`);

// 3. Unsafe dynamic CSS/HTML sinks are allowed only in audited, explicitly escaped locations.
for (const p of files(SRC)) {
  hit(p, /dangerouslySetInnerHTML\s*:/, 'dangerouslySetInnerHTML sink; verify input is static/escaped');
  hit(p, /\.innerHTML\s*=/, 'innerHTML assignment; verify input is trusted');
}

// 4. Migration layout: migrations must be direct children of supabase/migrations.
const migrations = join(SUPABASE, 'migrations');
if (statSync(migrations, { throwIfNoEntry: false })) {
  for (const p of walk(migrations)) {
    if (p !== migrations && statSync(p).isDirectory()) failures.push(`nested migration directory: ${relative(ROOT,p)}`);
  }
}

// 5. Server-only service-role usage must remain in server modules.
for (const p of files(SRC)) {
  const src = text(p);
  if (!src.includes('SUPABASE_SERVICE_ROLE_KEY')) continue;
  if (!/\.server\.(ts|tsx)$/.test(p) && !/server\//.test(p)) failures.push(`${relative(ROOT,p)} references SUPABASE_SERVICE_ROLE_KEY outside a server module`);
}

// 6. High-signal code smells: report rather than auto-mutate ambiguous cases.
for (const p of files(SRC)) {
  if (!/\.(test|spec)\.(ts|tsx|js|jsx)$/.test(p)) hit(p, /\bTODO\b|\bFIXME\b/, 'unfinished TODO/FIXME marker');
}

// 7. Require core reliability artifacts.
for (const required of [
  'src/lib/site-agent.atomic.ts',
  'src/lib/site-agent.functions.ts',
  'src/lib/site-style.ts',
  'src/components/site/SiteSections.tsx',
  'src/lib/public-site.server.ts',
  'src/lib/builder-queue.ts',
]) if (!statSync(join(ROOT, required), { throwIfNoEntry: false })) failures.push(`missing core file: ${required}`);

console.log(`Revora repository audit`);
console.log(`Files scanned: ${files(SRC).length}`);
console.log(`Agent actions discovered: ${new Set(actions).size}`);
console.log(`Failures: ${failures.length}`);
console.log(`Warnings: ${warnings.length}`);
for (const x of failures) console.log(`FAIL  ${x}`);
for (const x of warnings.slice(0, 80)) console.log(`WARN  ${x}`);
if (warnings.length > 80) console.log(`WARN  ... ${warnings.length - 80} more`);
process.exitCode = failures.length ? 1 : 0;
