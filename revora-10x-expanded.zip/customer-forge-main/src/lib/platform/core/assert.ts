export function invariant(condition: unknown, message: string): asserts condition { if (!condition) throw new Error(message); }
export function assertNever(value: never): never { throw new Error(`Unexpected value: ${String(value)}`); }
