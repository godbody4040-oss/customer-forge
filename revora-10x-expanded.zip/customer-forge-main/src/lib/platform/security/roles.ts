export const ROLE_RANK = { viewer:10, member:20, manager:30, owner:40, admin:50, super_admin:60 } as const;
export type Role = keyof typeof ROLE_RANK;
export const atLeast = (role: Role, minimum: Role): boolean => ROLE_RANK[role] >= ROLE_RANK[minimum];
