/**
 * Regression test for a real defect: a business that answered "Any" for its
 * service area (meaning "no specific area") shipped a live home page reading
 * "Any's go-to team for auto detailing" and "Serving Any" — because the raw
 * answer was used as a place name instead of being recognised as non-specific.
 */
import { describe, expect, it } from "vitest";
import { buildContentBlueprint, splitAreas, type BlueprintInput } from "@/lib/website-content";

const baseInput: BlueprintInput = {
  businessName: "Any's Auto Detailing",
  industry: "Auto detailing",
  city: null,
  state: null,
  serviceArea: "Any",
  description: null,
  phone: "9199843695",
  email: null,
  hasHours: false,
  photoCount: 0,
  reviewCount: 0,
  ctaLabel: "Get my quote",
  services: [{ name: "Full detail" }],
  benefits: [],
  faqs: [],
};

describe("buildContentBlueprint area handling", () => {
  it("never turns a non-specific service-area answer into a place name", () => {
    const pages = buildContentBlueprint(baseInput);
    const home = pages.find((page) => page.kind === "home");
    const headline = home?.sections
      .flatMap((section) => [section.heading, section.subheading, section.body])
      .filter((text): text is string => Boolean(text))
      .join(" ");
    expect(headline?.toLowerCase()).not.toContain("any's");
    expect(headline?.toLowerCase()).not.toContain("serving any");
  });

  it("falls back to city/state once the service area is dropped as non-specific", () => {
    const pages = buildContentBlueprint({ ...baseInput, city: "Raleigh", state: "NC" });
    const home = pages.find((page) => page.kind === "home");
    const headline = home?.sections
      .flatMap((section) => [section.heading, section.subheading])
      .filter((text): text is string => Boolean(text))
      .join(" ");
    expect(headline?.toLowerCase()).not.toContain("any");
  });
});

describe("splitAreas", () => {
  it("drops a non-specific answer instead of listing it as a served area", () => {
    expect(splitAreas("Any", null)).toEqual([]);
    expect(splitAreas("N/A", null)).toEqual([]);
  });

  it("still lists real areas, comma-separated", () => {
    expect(splitAreas("Raleigh, Durham & Cary", null)).toEqual(["Raleigh", "Durham", "Cary"]);
  });
});
