export const ONBOARDING_STEPS=['business_profile','brand','services','service_area','website','domain','lead_capture','booking','analytics','launch'] as const; export type OnboardingStep=typeof ONBOARDING_STEPS[number];
export const progress=(done:OnboardingStep[]):number=>Math.round(new Set(done).size/ONBOARDING_STEPS.length*100);
