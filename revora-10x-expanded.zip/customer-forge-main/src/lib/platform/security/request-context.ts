export type RequestContext = { requestId:string; ip?:string; userAgent?:string; organizationId?:string; userId?:string };
export const withRequestId = (ctx: Omit<RequestContext,'requestId'>, requestId = crypto.randomUUID()): RequestContext => ({...ctx,requestId});
