export const isSafeUrl = (value: string): boolean => { try { const u=new URL(value); return ['https:','http:'].includes(u.protocol) && !u.username && !u.password; } catch { return false; } };
export const isSafeHostname = (value: string): boolean => /^(?=.{1,253}$)([a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/i.test(value);
