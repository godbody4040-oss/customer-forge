export type RevenueEvent={amount:number;occurredAt:string;status:'won'|'refunded'|'void'};
export const recognizedRevenue=(events:RevenueEvent[]):number=>events.reduce((sum,e)=>sum+(e.status==='won'?e.amount:e.status==='refunded'?-e.amount:0),0);
