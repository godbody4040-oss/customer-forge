const BLOCKED = [/javascript:/i,/vbscript:/i,/data:text\/html/i,/\bonerror\s*=/i];
export const containsUnsafeMarkup = (value:string):boolean => BLOCKED.some(pattern=>pattern.test(value));
export const sanitizeText = (value:string):string => value.replace(/[<>]/g,'').trim();
