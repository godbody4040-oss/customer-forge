# Revora Premium Experience Layer

This release adds a production-safe premium layer to public client websites.

## What changed

- **3D-feeling service stage**: perspective, pointer tilt, orbital rings and depth using CSS transforms only. No WebGL dependency.
- **Smart service finder**: visitors describe what they need and the UI matches against the business's published services. It is deterministic and private rather than pretending to be an LLM.
- **Proof micro-signals**: rating, booking speed and service context are surfaced near the decision point.
- **Motion/accessibility budget**: reduced-motion users get a flat version and mobile keeps the visual treatment lighter.
- **Placeholder hygiene**: broad service-area placeholders such as `Any`, `Anywhere`, `All areas`, and `TBD` are treated as missing facts instead of being rendered to visitors.
- **Regression tests** cover the matcher and place-value hygiene.

## Product direction

The visual direction is intentionally based on patterns repeatedly found in strong detailing sites: high-contrast presentation, real work imagery, visible proof, productized services/pricing, and one obvious next action. The implementation keeps those conversion fundamentals while adding a more distinctive Revora visual system.

The public renderer remains server-friendly: the premium layer adds no new network request, third-party analytics, or mandatory AI provider.

## Next expansion candidates

1. Before/after drag comparison powered by existing gallery media.
2. Vehicle/service-size configurator backed by the existing quote engine.
3. Local availability indicator backed by real booking slots.
4. AI concierge backed by the existing provider router, with strict grounding to published business facts.
5. Image generation/retouch pipeline using the existing image studio for hero art and campaign variants.
6. Automated Lighthouse/Core Web Vitals budget gates in CI.
7. Visual regression snapshots for the public site renderer.

These are intentionally separated from the current release so a visual upgrade cannot destabilize booking, lead capture, or tenant isolation.
