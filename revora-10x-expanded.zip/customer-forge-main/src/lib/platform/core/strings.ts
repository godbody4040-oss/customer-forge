export const truncate = (value: string, max: number): string => value.length <= max ? value : `${value.slice(0,Math.max(0,max-1))}…`;
export const nonEmpty = (value: string | null | undefined): value is string => Boolean(value?.trim());
