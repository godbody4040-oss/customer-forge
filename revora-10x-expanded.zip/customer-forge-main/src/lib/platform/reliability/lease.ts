export type Lease={key:string;owner:string;expiresAt:number};
export const leaseValid=(lease:Lease,now=Date.now()):boolean=>lease.expiresAt>now;
