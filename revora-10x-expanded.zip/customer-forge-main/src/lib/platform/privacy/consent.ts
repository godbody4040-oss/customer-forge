export type ConsentPurpose='analytics'|'marketing'|'personalization'|'essential'; export type Consent={purpose:ConsentPurpose;granted:boolean;at:string;source:string};
export const canProcess=(consents:Consent[],purpose:ConsentPurpose):boolean=>purpose==='essential'||consents.some(c=>c.purpose===purpose&&c.granted);
