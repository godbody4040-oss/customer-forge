import { invariant } from '../core/assert';
export type TenantContext = { organizationId: string; userId: string; role: string };
export function requireTenant(context: TenantContext | null | undefined): TenantContext { invariant(context?.organizationId,'Missing tenant context'); invariant(context?.userId,'Missing user context'); return context; }
export function sameTenant(expected: string, actual: string): boolean { return expected.length > 0 && expected === actual; }
