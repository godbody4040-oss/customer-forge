export type FunnelStep={name:string;count:number};
export function funnelRates(steps:FunnelStep[]):number[]{return steps.map((s,i)=>i===0?100:steps[i-1]?.count?s.count/steps[i-1].count*100:0);}
