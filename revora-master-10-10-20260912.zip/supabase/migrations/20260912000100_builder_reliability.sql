-- Revora Builder Reliability
--
-- Builder staff can create restore points because an approved website edit is
-- a content operation. Managers/admins retain control of changing or deleting
-- historical versions.

DROP POLICY IF EXISTS "website_versions_write" ON public.website_versions;

CREATE POLICY "website_versions_write"
ON public.website_versions
FOR INSERT
TO authenticated
WITH CHECK (
  private.org_role_at_least(organization_id, 'staff')
  OR private.is_super_admin()
);

DROP POLICY IF EXISTS "website_versions_update" ON public.website_versions;

CREATE POLICY "website_versions_update"
ON public.website_versions
FOR UPDATE
TO authenticated
USING (
  private.org_role_at_least(organization_id, 'manager')
  OR private.is_super_admin()
)
WITH CHECK (
  private.org_role_at_least(organization_id, 'manager')
  OR private.is_super_admin()
);
