/**
 * Atomic apply journal for Revora's Website Agent.
 *
 * Supabase/PostgREST does not give the browser a multi-statement transaction for
 * a normal sequence of writes. This journal therefore records the exact state
 * before every mutation and can restore it in reverse order if any later step
 * fails. The apply layer also performs post-write verification; the journal is
 * the recovery mechanism, not the success signal.
 */
import type { AgentAction } from "@/lib/site-agent";

type Row = Record<string, unknown>;

type Chain = PromiseLike<{ data: unknown; error: unknown }> & {
  eq: (column: string, value: unknown) => Chain;
  in: (column: string, values: unknown[]) => Chain;
  gte: (column: string, value: unknown) => Chain;
  select: (columns?: string) => Chain;
  maybeSingle: () => PromiseLike<{ data: unknown; error: unknown }>;
};

export type JournalClient = {
  from: (table: string) => {
    select: (columns: string) => Chain;
    insert: (values: Row) => Chain;
    update: (values: Row) => Chain;
    delete: () => Chain;
  };
};

export type UndoStep = { label: string; run: () => Promise<void> };

const IMMUTABLE = new Set(["id", "organization_id", "created_at", "updated_at"]);

const restorable = (row: Row) =>
  Object.fromEntries(Object.entries(row).filter(([key]) => !IMMUTABLE.has(key)));

const queryError = (error: unknown, label: string) => {
  if (error) throw new Error(`${label}: ${error instanceof Error ? error.message : String(error)}`);
};

type Target =
  | { kind: "update"; table: string; id: string }
  | { kind: "updateMany"; table: string; ids: string[] }
  | { kind: "delete"; table: string; id: string }
  | { kind: "deleteSection"; id: string }
  | { kind: "deletePage"; id: string }
  | { kind: "org"; table: string }
  | { kind: "insert"; table: string };

export function targetOf(action: AgentAction): Target | null {
  switch (action.type) {
    case "set_section_text":
    case "set_section_visibility":
    case "set_section_variant":
    case "set_section_visual":
    case "set_section_effect":
      return { kind: "update", table: "website_sections", id: action.sectionId };
    case "reorder_sections":
      return { kind: "updateMany", table: "website_sections", ids: [...action.sectionIds] };
    case "delete_section":
      return { kind: "deleteSection", id: action.sectionId };
    case "add_section":
      return { kind: "insert", table: "website_sections" };
    case "set_component":
    case "set_component_visual":
      return { kind: "update", table: "website_components", id: action.componentId };
    case "add_component":
      return { kind: "insert", table: "website_components" };
    case "delete_component":
      return { kind: "delete", table: "website_components", id: action.componentId };
    case "add_page":
      return { kind: "insert", table: "website_pages" };
    case "set_page":
      return { kind: "update", table: "website_pages", id: action.pageId };
    case "delete_page":
      return { kind: "deletePage", id: action.pageId };
    case "set_theme":
    case "set_business_fact":
      return { kind: "org", table: "business_profiles" };
    case "set_backdrop":
      return { kind: "org", table: "website_settings" };
    default:
      return null;
  }
}

/** Capture exact pre-write state. Missing rows are errors, not successful no-ops. */
export async function captureUndo(
  client: JournalClient,
  orgId: string,
  action: AgentAction,
): Promise<UndoStep[]> {
  const target = targetOf(action);
  if (!target) return [];

  // Inserts are intentionally handled by the executor after it receives the
  // exact inserted id. A timestamp-based delete is unsafe under concurrency.
  if (target.kind === "insert") return [];

  if (target.kind === "update" || target.kind === "delete") {
    const { data, error } = await client
      .from(target.table)
      .select("*")
      .eq("id", target.id)
      .eq("organization_id", orgId)
      .maybeSingle();
    queryError(error, `${action.type}: read before write`);
    const row = (data ?? null) as Row | null;
    if (!row) throw new Error(`${action.type}: target no longer exists`);

    if (target.kind === "update") {
      return [
        {
          label: `${action.type}:restore`,
          run: async () => {
            const { data: restored, error: restoreError } = await client
              .from(target.table)
              .update(restorable(row))
              .eq("id", target.id)
              .eq("organization_id", orgId)
              .select("id")
              .maybeSingle();
            queryError(restoreError, `${action.type}: rollback`);
            if (!restored) throw new Error(`${action.type}: rollback target disappeared`);
          },
        },
      ];
    }

    return [
      {
        label: `${action.type}:reinsert`,
        run: async () => {
          const { data: inserted, error: insertError } = await client
            .from(target.table)
            .insert(row)
            .select("id")
            .maybeSingle();
          queryError(insertError, `${action.type}: rollback reinsert`);
          if (!inserted) throw new Error(`${action.type}: rollback reinsert was not confirmed`);
        },
      },
    ];
  }

  if (target.kind === "deleteSection") {
    const { data: section, error: sectionError } = await client
      .from("website_sections")
      .select("*")
      .eq("id", target.id)
      .eq("organization_id", orgId)
      .maybeSingle();
    queryError(sectionError, "delete_section: read before write");
    const sectionRow = (section ?? null) as Row | null;
    if (!sectionRow) throw new Error("delete_section: target no longer exists");

    const { data: components, error: componentError } = await client
      .from("website_components")
      .select("*")
      .eq("organization_id", orgId)
      .eq("section_id", target.id);
    queryError(componentError, "delete_section: read child components");
    const childRows = (components ?? []) as Row[];

    // Return the parent restore first; rollback executes in reverse, so child
    // components are recreated before their section. This makes destructive
    // deletes genuinely reversible even with ON DELETE CASCADE.
    return [
      {
        label: "delete_section:restore",
        run: async () => {
          const { data: restored, error } = await client
            .from("website_sections")
            .insert(sectionRow)
            .select("id")
            .maybeSingle();
          queryError(error, "delete_section: rollback section");
          if (!restored) throw new Error("delete_section: rollback section was not confirmed");
        },
      },
      ...childRows.map((row) => ({
        label: `delete_section:restore-component:${String(row["id"])}`,
        run: async () => {
          const { data: restored, error } = await client
            .from("website_components")
            .insert(row)
            .select("id")
            .maybeSingle();
          queryError(error, "delete_section: rollback component");
          if (!restored) throw new Error("delete_section: rollback component was not confirmed");
        },
      })),
    ];
  }

  if (target.kind === "deletePage") {
    const { data: page, error: pageError } = await client
      .from("website_pages")
      .select("*")
      .eq("id", target.id)
      .eq("organization_id", orgId)
      .maybeSingle();
    queryError(pageError, "delete_page: read before write");
    const pageRow = (page ?? null) as Row | null;
    if (!pageRow) throw new Error("delete_page: target no longer exists");

    const { data: sections, error: sectionError } = await client
      .from("website_sections")
      .select("*")
      .eq("organization_id", orgId)
      .eq("page_id", target.id);
    queryError(sectionError, "delete_page: read child sections");
    const sectionRows = (sections ?? []) as Row[];
    const sectionIds = sectionRows.map((row) => String(row["id"]));

    const { data: components, error: componentError } = sectionIds.length
      ? await client
          .from("website_components")
          .select("*")
          .eq("organization_id", orgId)
          .in("section_id", sectionIds)
      : { data: [], error: null };
    queryError(componentError, "delete_page: read child components");
    const componentRows = (components ?? []) as Row[];

    return [
      {
        label: "delete_page:restore",
        run: async () => {
          const { data: restored, error } = await client
            .from("website_pages")
            .insert(pageRow)
            .select("id")
            .maybeSingle();
          queryError(error, "delete_page: rollback page");
          if (!restored) throw new Error("delete_page: rollback page was not confirmed");
        },
      },
      ...sectionRows.map((row) => ({
        label: `delete_page:restore-section:${String(row["id"])}`,
        run: async () => {
          const { data: restored, error } = await client
            .from("website_sections")
            .insert(row)
            .select("id")
            .maybeSingle();
          queryError(error, "delete_page: rollback section");
          if (!restored) throw new Error("delete_page: rollback section was not confirmed");
        },
      })),
      ...componentRows.map((row) => ({
        label: `delete_page:restore-component:${String(row["id"])}`,
        run: async () => {
          const { data: restored, error } = await client
            .from("website_components")
            .insert(row)
            .select("id")
            .maybeSingle();
          queryError(error, "delete_page: rollback component");
          if (!restored) throw new Error("delete_page: rollback component was not confirmed");
        },
      })),
    ];
  }

  if (target.kind === "updateMany") {
    const { data, error } = await client
      .from(target.table)
      .select("*")
      .eq("organization_id", orgId)
      .in("id", target.ids);
    queryError(error, `${action.type}: read before write`);
    const rows = (data ?? []) as Row[];
    const found = new Set(rows.map((row) => String(row["id"])));
    const missing = target.ids.filter((id) => !found.has(id));
    if (missing.length) throw new Error(`${action.type}: target rows no longer exist`);

    return rows.map((row) => ({
      label: `${action.type}:restore:${String(row["id"])}`,
      run: async () => {
        const { data: restored, error: restoreError } = await client
          .from(target.table)
          .update(restorable(row))
          .eq("id", String(row["id"]))
          .eq("organization_id", orgId)
          .select("id")
          .maybeSingle();
        queryError(restoreError, `${action.type}: rollback`);
        if (!restored) throw new Error(`${action.type}: rollback target disappeared`);
      },
    }));
  }

  // Organization-scoped singleton tables.
  const { data, error } = await client
    .from(target.table)
    .select("*")
    .eq("organization_id", orgId)
    .maybeSingle();
  queryError(error, `${action.type}: read before write`);
  const row = (data ?? null) as Row | null;

  if (!row) {
    return [
      {
        label: `${action.type}:remove-created-singleton`,
        run: async () => {
          const { error: deleteError } = await client
            .from(target.table)
            .delete()
            .eq("organization_id", orgId);
          queryError(deleteError, `${action.type}: rollback delete`);
        },
      },
    ];
  }

  return [
    {
      label: `${action.type}:restore`,
      run: async () => {
        const { data: restored, error: restoreError } = await client
          .from(target.table)
          .update(restorable(row))
          .eq("organization_id", orgId)
          .select("id")
          .maybeSingle();
        queryError(restoreError, `${action.type}: rollback`);
        if (!restored) throw new Error(`${action.type}: rollback target disappeared`);
      },
    },
  ];
}

export async function rollback(steps: UndoStep[]): Promise<{ undone: number; failed: number }> {
  let undone = 0;
  let failed = 0;
  for (const step of [...steps].reverse()) {
    try {
      await step.run();
      undone += 1;
    } catch (error) {
      failed += 1;
      console.error("[site-agent] rollback step failed", step.label, error);
    }
  }
  return { undone, failed };
}

export function describeActionTarget(action: AgentAction): string {
  switch (action.type) {
    case "set_section_text":
    case "set_section_visibility":
    case "set_section_variant":
    case "set_section_visual":
    case "set_section_effect":
    case "delete_section":
      return `section:${action.sectionId}`;
    case "set_component":
    case "set_component_visual":
    case "delete_component":
      return `component:${action.componentId}`;
    case "set_page":
    case "delete_page":
      return `page:${action.pageId}`;
    case "reorder_sections":
      return `page:${action.pageId}`;
    case "set_theme":
    case "set_business_fact":
    case "set_backdrop":
      return "workspace";
    case "add_section":
    case "add_component":
    case "add_page":
      return "new-record";
    default:
      return action.type;
  }
}
