export type RobotsRule={userAgent:string;allow?:string[];disallow?:string[]};
export const defaultRobots=():RobotsRule[]=>[{userAgent:'*',allow:['/'],disallow:['/app','/admin','/api']}];
