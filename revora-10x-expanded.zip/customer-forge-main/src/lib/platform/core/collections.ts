export function unique<T>(items: T[]): T[] { return [...new Set(items)]; }
export function groupBy<T, K extends PropertyKey>(items: T[], key: (item:T)=>K): Record<K,T[]> { return items.reduce((acc,item)=>{ const k=key(item); (acc[k] ??= []).push(item); return acc; }, {} as Record<K,T[]>); }
