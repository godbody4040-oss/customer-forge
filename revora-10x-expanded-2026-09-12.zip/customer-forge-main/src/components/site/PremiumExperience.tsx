import { useEffect, useMemo, useState, type CSSProperties } from "react";
import { ArrowRight, Bot, CalendarCheck, ChevronRight, Sparkles, WandSparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import type { PublicSite } from "@/lib/public-site.functions";
import { currency } from "@/lib/format";
import { premiumMatch, type PremiumMatch } from "@/lib/premium-experience";

type Site = NonNullable<PublicSite>;

function useReducedMotion() {
  const [reduced, setReduced] = useState(false);
  useEffect(() => {
    const query = window.matchMedia("(prefers-reduced-motion: reduce)");
    const update = () => setReduced(query.matches);
    update();
    query.addEventListener("change", update);
    return () => query.removeEventListener("change", update);
  }, []);
  return reduced;
}

/**
 * A conversion-focused "premium layer" for public sites.
 *
 * It is deliberately local and deterministic: no fake AI claims, no third-party
 * widget, no network call. The matcher uses the services already published by
 * the business, while the visual stage adds depth without requiring WebGL.
 */
export function PremiumExperience({ site }: { site: Site }) {
  const { profile, services, reviews, gallery, org } = site;
  const reducedMotion = useReducedMotion();
  const [query, setQuery] = useState("");
  const [match, setMatch] = useState<PremiumMatch | null>(null);
  const [pointer, setPointer] = useState({ x: 50, y: 50 });

  const featured = useMemo(
    () => services.filter((service) => service.featured).slice(0, 3).concat(services.slice(0, 3)).slice(0, 3),
    [services],
  );
  const heroImage = profile?.hero_image_url || gallery[0]?.url || null;
  const rating = reviews.length
    ? reviews.reduce((sum, review) => sum + review.rating, 0) / reviews.length
    : null;

  useEffect(() => {
    if (!query.trim()) {
      setMatch(null);
      return;
    }
    setMatch(premiumMatch(query, services));
  }, [query, services]);

  return (
    <section
      className="premium-experience border-b border-border"
      aria-label={`Interactive ${org.name} experience`}
    >
      <div className="mx-auto max-w-6xl px-4 py-10 lg:py-14">
        <div className="premium-grid">
          <div
            className="premium-stage"
            onPointerMove={(event) => {
              if (reducedMotion) return;
              const rect = event.currentTarget.getBoundingClientRect();
              setPointer({
                x: ((event.clientX - rect.left) / rect.width) * 100,
                y: ((event.clientY - rect.top) / rect.height) * 100,
              });
            }}
            onPointerLeave={() => setPointer({ x: 50, y: 50 })}
            style={
              reducedMotion
                ? undefined
                : ({
                    "--px": `${pointer.x}%`,
                    "--py": `${pointer.y}%`,
                    "--rx": `${((50 - pointer.y) / 50) * 4}deg`,
                    "--ry": `${((pointer.x - 50) / 50) * 4}deg`,
                  } as CSSProperties)
            }
          >
            <div className="premium-stage-grid" aria-hidden="true" />
            <div className="premium-orbit premium-orbit-a" aria-hidden="true" />
            <div className="premium-orbit premium-orbit-b" aria-hidden="true" />

            <div className="premium-vehicle-card">
              {heroImage ? (
                <img
                  src={heroImage}
                  alt=""
                  loading="lazy"
                  className="premium-vehicle-image"
                />
              ) : (
                <div className="premium-vehicle-placeholder" aria-hidden="true">
                  <Sparkles className="size-10" />
                </div>
              )}
              <div className="premium-vehicle-overlay" />
              <div className="premium-stage-copy">
                <span className="premium-kicker">
                  <WandSparkles className="size-3.5" aria-hidden="true" />
                  Crafted around your business
                </span>
                <p className="mt-2 font-display text-xl font-semibold">
                  {featured[0]?.name || "Premium service"}
                </p>
                <p className="mt-1 text-xs text-white/70">
                  {featured[0]?.description || "A clearer path from first visit to booked job."}
                </p>
              </div>
            </div>

            <div className="premium-floating-card premium-floating-card-top">
              <span className="premium-live-dot" />
              <span>{rating ? `${rating.toFixed(1)}★ customer rated` : "Built to convert"}</span>
            </div>

            <div className="premium-floating-card premium-floating-card-bottom">
              <CalendarCheck className="size-4 text-primary" aria-hidden="true" />
              <span>Book in two minutes</span>
            </div>
          </div>

          <div className="premium-concierge panel-glass p-5 sm:p-6">
            <div className="flex items-start gap-3">
              <span className="grid size-10 shrink-0 place-items-center rounded-xl border border-primary/30 bg-primary/10 text-primary">
                <Bot className="size-5" aria-hidden="true" />
              </span>
              <div>
                <p className="eyebrow">Smart service finder</p>
                <h2 className="mt-1 font-display text-2xl font-semibold tracking-tight">
                  Not sure what you need?
                </h2>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                  Tell us what you want done. We’ll match your words to the services this business actually offers.
                </p>
              </div>
            </div>

            <label className="mt-5 block">
              <span className="sr-only">Describe what you need</span>
              <input
                value={query}
                onChange={(event) => setQuery(event.target.value.slice(0, 180))}
                placeholder="e.g. deep interior clean, ceramic coating…"
                className="h-12 w-full rounded-xl border border-border bg-background/70 px-4 text-sm outline-none transition focus:border-primary focus:ring-2 focus:ring-primary/20"
              />
            </label>

            {match ? (
              <div className="premium-match mt-3 rounded-xl border border-primary/30 bg-primary/5 p-4">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="text-xs font-medium uppercase tracking-wider text-primary">Best match</p>
                    <p className="mt-1 font-display font-semibold">{match.service.name}</p>
                    {match.service.description ? (
                      <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
                        {match.service.description}
                      </p>
                    ) : null}
                  </div>
                  <ChevronRight className="mt-1 size-4 text-primary" aria-hidden="true" />
                </div>
                <div className="mt-3 flex flex-wrap items-center justify-between gap-3">
                  <span className="text-xs text-muted-foreground">
                    {match.service.price !== null
                      ? `${match.service.starting_price ? "From " : ""}${currency(Number(match.service.starting_price ?? match.service.price))}`
                      : "Price on request"}
                  </span>
                  <Button asChild size="sm" variant="signal">
                    <a href={site.quote ? "#quote" : "#book"}>
                      Get started <ArrowRight className="size-3.5" aria-hidden="true" />
                    </a>
                  </Button>
                </div>
              </div>
            ) : null}

            <div className="mt-5 grid gap-2 sm:grid-cols-3">
              {featured.map((service) => (
                <button
                  key={service.id}
                  type="button"
                  onClick={() => setQuery(service.name)}
                  className="group rounded-xl border border-border bg-background/45 p-3 text-left transition hover:-translate-y-0.5 hover:border-primary/40 hover:bg-primary/5"
                >
                  <span className="line-clamp-1 text-xs font-medium">{service.name}</span>
                  <span className="mt-1 flex items-center gap-1 text-[11px] text-muted-foreground group-hover:text-primary">
                    Explore <ChevronRight className="size-3" aria-hidden="true" />
                  </span>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
