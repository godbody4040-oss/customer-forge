import { canProcess } from '../privacy/consent'; import type { Consent } from '../privacy/consent';
export const analyticsAllowed=(consents:Consent[]):boolean=>canProcess(consents,'analytics');
