export type ReleaseState='draft'|'staging'|'canary'|'production'|'rolled-back';
export type Release={version:string,state:ReleaseState,commit:string,at:string};
