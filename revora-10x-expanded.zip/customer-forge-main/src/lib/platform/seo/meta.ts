export type SeoMeta={title:string;description:string;canonical?:string;robots?:string};
export const normalizeMeta=(meta:SeoMeta):SeoMeta=>({...meta,title:meta.title.trim().slice(0,60),description:meta.description.trim().slice(0,160)});
