#!/usr/bin/env python3
"""Fast static guardrail for the Revora repository.

It intentionally checks only things that are deterministic in CI: action parity,
secret-like literals, environment files, nested Supabase migrations, unsafe HTML
sinks, and SECURITY DEFINER functions without an explicit search_path.
"""
from __future__ import annotations

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
errors: list[str] = []
warnings: list[str] = []

agent = (ROOT / "src/lib/site-agent.ts").read_text(encoding="utf-8")
executor = (ROOT / "src/lib/site-agent.functions.ts").read_text(encoding="utf-8")
actions = []
for value in re.findall(r'type:\s*"([a-z_]+)"', agent):
    if value not in actions:
        actions.append(value)
executed = set(re.findall(r'case\s*"([a-z_]+)"', executor))
missing = [value for value in actions if value not in executed]
if missing:
    errors.append(f"Agent actions without an executor: {', '.join(missing)}")

for path in (ROOT / "supabase/migrations").rglob("*.sql"):
    if path.parent != ROOT / "supabase/migrations":
        errors.append(f"Nested Supabase migration: {path.relative_to(ROOT)}")

for name in (".env", ".env.development", ".env.production"):
    if (ROOT / name).exists():
        errors.append(f"Deployment environment file is present in the repository: {name}")

secret_re = re.compile(r"sk_(?:live|test)_[A-Za-z0-9]{20,}|whsec_[A-Za-z0-9]{20,}|BEGIN (?:RSA|EC|OPENSSH|PRIVATE) KEY")
for path in ROOT.rglob("*"):
    if not path.is_file() or "node_modules" in path.parts or ".git" in path.parts:
        continue
    if path.suffix in {".lock", ".png", ".jpg", ".jpeg", ".gif", ".ico", ".webp", ".woff", ".woff2"}:
        continue
    try:
        text = path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        continue
    if secret_re.search(text):
        errors.append(f"Secret-like literal found in {path.relative_to(ROOT)}")

for path in (ROOT / "src").rglob("*.tsx"):
    text = path.read_text(encoding="utf-8")
    if ".server" in text and re.search(r'import[^;]+\.server', text):
        warnings.append(f"Review server-only import in component: {path.relative_to(ROOT)}")

for path in (ROOT / "supabase/migrations").glob("*.sql"):
    text = path.read_text(encoding="utf-8")
    # SECURITY DEFINER is only safe when the function pins name resolution.
    for match in re.finditer(r"security\s+definer", text, re.I):
        chunk = text[max(0, match.start() - 700) : match.start() + 700]
        if "set search_path" not in chunk.lower():
            # Ignore migrations that merely ALTER existing functions or mention the
            # phrase in comments; report only when a CREATE FUNCTION appears nearby.
            if re.search(r"create\s+(?:or\s+replace\s+)?function", chunk, re.I):
                errors.append(f"SECURITY DEFINER function without pinned search_path: {path.relative_to(ROOT)}")
                break

if missing:
    print("FAIL")
else:
    print("PASS")
for item in errors:
    print(f"ERROR: {item}")
for item in warnings:
    print(f"WARN: {item}")
raise SystemExit(1 if errors else 0)
