# Revora / Customer Forge — Master Repository Audit

Date: 2026-09-12

## Scope

This pass started from the supplied `customer-forge-main` repository and the previously hardened Revora pack. The repository was scanned across `src`, `supabase`, `scripts`, `cloudflare`, `public`, configuration, builder actions, restore/versioning, rendering, queue state, and security-sensitive code paths.

The goal was not to redesign the app from scratch. The goal was to make the existing product safer, more reliable, easier to use, and closer to the strongest current AI website-builder workflows.

## Highest-impact problems found and fixed

### 1. AI action/executor contract mismatch

`set_section_visual` and `set_component_visual` were valid AI actions but previously had no real executor path.

Fixed:
- both actions execute
- both actions are journaled
- both actions read the row back after saving
- saved visual values are compared with the requested values
- failures trigger the atomic rollback path

### 2. Section variants could be stored without meaningful rendering

A saved `stacked`/`split`/other variant did not consistently control the public renderer.

Fixed:
- allowlisted section variants by section kind
- hero variant aliases mapped to actual visual layouts
- stacked, split, image-left, image-right, centered, editorial, layered and full-bleed hero compositions
- service list/grid/columns behavior
- review strip/quotes/card behavior
- CTA band/panel/inline behavior
- responsive mobile fallback

### 3. Destructive section/page rollback was incomplete

Deleting a section or page cascades into child components. A row-only undo journal could restore the parent while losing its children.

Fixed:
- delete-section journal captures child components
- delete-page journal captures sections and components
- rollback restores children before parents
- exact row IDs are retained

### 4. Version snapshots were not actually complete

The old agent snapshot intentionally stripped component/section settings and media, so a version could not restore visual design exactly. Global theme/backdrop state was also outside the structure snapshot.

Fixed:
- version snapshots now use the full snapshot model
- section settings preserved
- component settings preserved
- component media URLs preserved
- complete page SEO fields preserved
- global website settings preserved
- theme fields preserved
- restore matching now includes global design state
- database restore function now restores global design state when present

### 5. Zero-row database writes could be treated as success

Supabase/PostgREST can return no error when an update/delete matches zero rows.

Fixed in the main builder/editor paths:
- mutation requests require returned row IDs
- visual actions read back saved values
- variants read back exact values
- effects read back exact values
- theme values read back exact values
- backdrop reads back exact value
- business facts read back exact value

### 6. Rebuild could leave a half-built website

`useBuildWebsiteStructure` deleted the current page tree before creating the new one. A later insert failure could leave the workspace incomplete.

Fixed:
- refuses to rebuild from an empty blueprint
- captures an exact restore point before destructive rebuild
- restores automatically if rebuild fails
- verifies the automatic restore
- refuses to claim recovery if restore verification fails

### 7. Queue action collision

Queued tasks stored their AI actions in one shared map. Two plans with the same step key could overwrite each other before the earlier task ran.

Fixed:
- actions are namespaced by task ID
- completed/failed task actions are cleaned up
- queued builds cannot collide through shared action keys

### 8. Server/client security boundaries

Scanned component code for direct imports of `.server` modules.

Result:
- no component `.server` imports found in the final scan
- service-role access remains in server-only modules
- no secret-like API literals found

### 9. Environment hygiene

The source archive contained deployment environment files.

Fixed:
- deployment `.env` files removed from the master pack
- `.gitignore` now blocks `.env`, `.env.*`, while preserving `.env.example`

### 10. Supabase migration packaging

A migration existed under a nested `supabase/migrations/supabase/migrations/` directory, which Supabase would not treat as a normal migration.

Fixed:
- nested migration removed
- master hardening migration placed directly under `supabase/migrations/`

## Product-level improvements benchmarked

Current builder products emphasize visual editing, batched changes, queueing, version history, preview/revert, and security checks. Revora's architecture now reinforces those same principles without copying proprietary implementation.

- Bolt Visual Edits supports click-based edits, stacking multiple changes, and sending them as one batch.
- Bolt also now supports prompt queueing so the next request waits for the current build.
- Lovable provides project security scanning across RLS, database security, code security and dependencies, and recommends refreshing checks before publishing.
- Base44 provides version-history workflows that let users preview, publish, revert and inspect earlier versions.

## Static validation performed

Passed:

- `python3 scripts/master-repo-audit.py`
- Python syntax compilation for repository audit/QA scripts
- TypeScript/TSX parser-level scan across the repository
- Agent action → executor parity scan
- nested migration scan
- secret-like literal scan
- server-only component import scan
- SECURITY DEFINER/search_path guard scan

The parser-level TypeScript scan reported no syntax errors.

## What could not honestly be claimed

A full `npm run typecheck`, `npm run test`, or `npm run build` was not executed successfully in this analysis runtime because the uploaded repository did not have its npm dependencies installed and the environment could not complete dependency installation. No claim of a full production build/test pass is made.

Run these in the GitHub checkout after installing dependencies:

```bash
npm install
npm run audit:repo
npm run typecheck
npm test
npm run build
```

If the project is managed with Bun in your deployment environment, use the equivalent Bun commands.

## Files changed in the master pass

- `package.json`
- `.gitignore`
- `scripts/master-repo-audit.py`
- `src/components/app/AiRequestPanel.tsx`
- `src/components/app/BuilderCanvas.tsx`
- `src/components/site/SiteSections.tsx`
- `src/lib/site-agent.atomic.ts`
- `src/lib/site-agent.functions.ts`
- `src/lib/site-agent.ts`
- `src/lib/site-restore.functions.ts`
- `src/lib/site-restore.test.ts`
- `src/lib/site-restore.ts`
- `src/lib/site-style.ts`
- `src/lib/site-variation.ts`
- `src/lib/site-visual-contract.test.ts`
- `src/lib/website-content.hooks.ts`
- `src/styles.css`
- `supabase/migrations/20260912010000_revora_master_hardening.sql`

## Expected builder behavior after deployment

For a request such as:

> Improve the overall look of my website: consistent spacing, clearer headings, a tidy layout and a colour and button style that suits my industry. Keep all my real business details exactly as they are.

Revora should now:

1. inspect the real site
2. produce an editable plan
3. validate every action
4. create a verified restore point
5. apply approved actions
6. read critical values back from Supabase
7. render the real draft
8. run post-write verification
9. rollback if a critical check fails
10. report the actual result rather than showing a generic false-success state

## Long-term 10/10 roadmap

The next major product layer should be a first-class visual inspector that lets users click an element and stage text/style/layout changes visually, then save them as one verified batch. This aligns with the strongest current builder UX pattern and would make the prompt builder and visual builder feel like one system rather than two separate editors.
