export const exponentialBackoff=(attempt:number,base=250,max=30_000,jitter=0.2):number=>{const raw=Math.min(max,base*2**Math.max(0,attempt));return Math.round(raw*(1+(Math.random()*2-1)*jitter));};
