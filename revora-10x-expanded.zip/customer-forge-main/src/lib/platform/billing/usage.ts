export type Usage={key:string;used:number;limit:number}; export const withinLimit=(u:Usage,delta=1):boolean=>u.used+delta<=u.limit;
