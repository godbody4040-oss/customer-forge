export type AuditEnvelope = { event:string; actorId?:string; organizationId?:string; at:string; metadata:Record<string,unknown> };
export function validateAuditEnvelope(e: AuditEnvelope): void { if (!e.event || !e.at) throw new Error('Invalid audit envelope'); if (e.event.length > 200) throw new Error('Audit event too long'); }
