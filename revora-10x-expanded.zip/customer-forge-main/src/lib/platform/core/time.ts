export const nowIso = (): string => new Date().toISOString();
export const addMinutes = (date: Date, minutes: number): Date => new Date(date.getTime()+minutes*60_000);
export const isExpired = (iso: string, now = new Date()): boolean => new Date(iso).getTime() <= now.getTime();
