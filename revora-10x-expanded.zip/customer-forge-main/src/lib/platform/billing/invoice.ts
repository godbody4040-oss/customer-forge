export type InvoiceStatus='draft'|'open'|'paid'|'void'|'uncollectible'; export type Invoice={id:string;organizationId:string;amount:number;currency:string;status:InvoiceStatus;dueAt?:string};
