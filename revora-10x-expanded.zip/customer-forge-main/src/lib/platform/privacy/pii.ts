export const looksLikePhone=(v:string):boolean=>/^\+?[0-9 ()-]{7,20}$/.test(v.trim());
export const looksLikeEmail=(v:string):boolean=>/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v.trim());
